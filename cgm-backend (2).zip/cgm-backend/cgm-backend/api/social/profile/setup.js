const { supabaseAdmin } = require('../../_supabase');
const { verifyAppToken } = require('../../_jwt');

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ ok: false, message: 'Method not allowed' });

  const claims = verifyAppToken(req.headers.authorization);
  if (!claims) return res.status(401).json({ ok: false, message: 'Not signed in.' });

  const { username, display_name, avatar_url } = req.body || {};
  if (!display_name || typeof display_name !== 'string' || display_name.length < 1 || display_name.length > 32) {
    return res.status(400).json({ ok: false, error: 'Display name must be 1-32 characters.' });
  }

  const patch = { display_name, updated_at: new Date().toISOString() };
  if (username) patch.username = username;
  if (avatar_url) patch.avatar_url = avatar_url;

  const { data, error } = await supabaseAdmin
    .from('social_profiles')
    .update(patch)
    .eq('discord_id', claims.id)
    .select('*')
    .single();

  if (error) {
    console.error('[profile/setup] update failed:', error);
    return res.status(500).json({ ok: false, error: 'Could not save that name. Please try again.' });
  }

  return res.status(200).json({ ok: true, data });
};
