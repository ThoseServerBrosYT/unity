const { supabaseAdmin } = require('../_supabase');
const { verifyAppToken } = require('../_jwt');

module.exports = async function handler(req, res) {
  const claims = verifyAppToken(req.headers.authorization);
  if (!claims) return res.status(401).json({ ok: false });

  const u = String(req.query.u || '').trim();
  if (!u) return res.status(400).json({ ok: false, available: false });

  const { data, error } = await supabaseAdmin
    .from('social_profiles')
    .select('discord_id')
    .ilike('display_name', u)
    .neq('discord_id', claims.id)
    .maybeSingle();

  if (error) return res.status(500).json({ ok: false });
  return res.status(200).json({ ok: true, available: !data });
};
