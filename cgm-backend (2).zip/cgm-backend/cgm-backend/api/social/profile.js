const { supabaseAdmin } = require('../_supabase');
const { verifyAppToken } = require('../_jwt');

module.exports = async function handler(req, res) {
  const claims = verifyAppToken(req.headers.authorization);
  if (!claims) return res.status(401).json({ ok: false, message: 'Not signed in.' });

  if (req.method === 'GET') {
    const { data, error } = await supabaseAdmin
      .from('social_profiles')
      .select('*')
      .eq('discord_id', claims.id)
      .maybeSingle();
    if (error) return res.status(500).json({ ok: false });
    return res.status(200).json({ ok: true, data });
  }

  if (req.method === 'PUT') {
    const allowed = ['who_can_add', 'who_can_invite', 'appear_in_suggestions', 'share_last_seen', 'profile_visibility'];
    const patch = {};
    for (const k of allowed) if (k in (req.body || {})) patch[k] = req.body[k];
    patch.updated_at = new Date().toISOString();

    const { data, error } = await supabaseAdmin
      .from('social_profiles')
      .update(patch)
      .eq('discord_id', claims.id)
      .select('*')
      .single();
    if (error) return res.status(500).json({ ok: false });
    return res.status(200).json({ ok: true, data });
  }

  return res.status(405).json({ ok: false, message: 'Method not allowed' });
};
