// friendships rows are keyed (user_a, user_b) with the constraint user_a < user_b
// so a relationship between two people is always exactly one row, never two.
function pair(a, b) {
  return a < b ? [a, b] : [b, a];
}
module.exports = { pair };
