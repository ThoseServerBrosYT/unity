const { supabaseAdmin } = require('../../_supabase');
const { verifyAppToken } = require('../../_jwt');
const { pair } = require('../_pair');

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ ok: false });
  const claims = verifyAppToken(req.headers.authorization);
  if (!claims) return res.status(401).json({ ok: false });

  const { username } = req.body || {};
  if (!username) return res.status(400).json({ ok: false, error: 'Missing username' });

  const { data: target } = await supabaseAdmin
    .from('social_profiles')
    .select('discord_id')
    .ilike('display_name', username)
    .maybeSingle();

  if (!target) return res.status(404).json({ ok: false, error: 'No one found with that name.' });
  if (target.discord_id === claims.id) return res.status(400).json({ ok: false, error: "That's you!" });

  const [user_a, user_b] = pair(claims.id, target.discord_id);

  const { data: existing } = await supabaseAdmin
    .from('friendships')
    .select('*')
    .eq('user_a', user_a)
    .eq('user_b', user_b)
    .maybeSingle();

  if (existing) {
    if (existing.status === 'accepted') return res.status(400).json({ ok: false, error: 'Already friends.' });
    if (existing.status === 'blocked')   return res.status(403).json({ ok: false, error: 'Unable to send request.' });
    return res.status(400).json({ ok: false, error: 'Request already pending.' });
  }

  const { error } = await supabaseAdmin.from('friendships').insert({
    user_a, user_b, status: 'pending', initiated_by: claims.id,
  });
  if (error) return res.status(500).json({ ok: false });

  return res.status(200).json({ ok: true });
};
