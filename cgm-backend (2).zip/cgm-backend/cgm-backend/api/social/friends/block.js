const { supabaseAdmin } = require('../../_supabase');
const { verifyAppToken } = require('../../_jwt');
const { pair } = require('../_pair');

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ ok: false });
  const claims = verifyAppToken(req.headers.authorization);
  if (!claims) return res.status(401).json({ ok: false });

  const { discordId } = req.body || {};
  if (!discordId) return res.status(400).json({ ok: false });

  const [user_a, user_b] = pair(claims.id, discordId);

  const { error } = await supabaseAdmin
    .from('friendships')
    .upsert(
      { user_a, user_b, status: 'blocked', initiated_by: claims.id, updated_at: new Date().toISOString() },
      { onConflict: 'user_a,user_b' }
    );

  if (error) return res.status(500).json({ ok: false });
  return res.status(200).json({ ok: true });
};
