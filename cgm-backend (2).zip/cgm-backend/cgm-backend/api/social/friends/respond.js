const { supabaseAdmin } = require('../../_supabase');
const { verifyAppToken } = require('../../_jwt');
const { pair } = require('../_pair');

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ ok: false });
  const claims = verifyAppToken(req.headers.authorization);
  if (!claims) return res.status(401).json({ ok: false });

  const { actorId, accept } = req.body || {};
  if (!actorId) return res.status(400).json({ ok: false });

  const [user_a, user_b] = pair(claims.id, actorId);
  const { data: row } = await supabaseAdmin
    .from('friendships').select('*').eq('user_a', user_a).eq('user_b', user_b).maybeSingle();

  if (!row || row.status !== 'pending' || row.initiated_by === claims.id) {
    return res.status(404).json({ ok: false, error: 'No pending request from that person.' });
  }

  if (!accept) {
    const { error } = await supabaseAdmin.from('friendships').delete().eq('user_a', user_a).eq('user_b', user_b);
    if (error) return res.status(500).json({ ok: false });
    return res.status(200).json({ ok: true, declined: true });
  }

  const { error } = await supabaseAdmin
    .from('friendships')
    .update({ status: 'accepted', updated_at: new Date().toISOString() })
    .eq('user_a', user_a).eq('user_b', user_b);
  if (error) return res.status(500).json({ ok: false });

  return res.status(200).json({ ok: true, accepted: true });
};
