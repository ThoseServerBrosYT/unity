const { supabaseAdmin } = require('./_supabase');
const { signAppToken, signSupabaseToken, verifyAppToken } = require('./_jwt');

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ message: 'Method not allowed' });

  const isRenew = req.query.action === 'renew';
  try {
    if (isRenew) return await handleRenew(req, res);
    return await handleLogin(req, res);
  } catch (err) {
    console.error('[auth] unhandled error:', err);
    return res.status(500).json({ message: 'Internal error, please try again.' });
  }
};

async function handleLogin(req, res) {
  const { code, redirectUri } = req.body || {};
  if (!code || !redirectUri) {
    return res.status(400).json({ message: 'Missing code or redirectUri' });
  }

  // 1. Exchange the one-time Discord code for an access token. This is why
  //    the client secret must live here and only here.
  const tokenResp = await fetch('https://discord.com/api/oauth2/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id:     process.env.DISCORD_CLIENT_ID,
      client_secret: process.env.DISCORD_CLIENT_SECRET,
      grant_type:    'authorization_code',
      code,
      redirect_uri:  redirectUri,
    }),
  });
  if (!tokenResp.ok) {
    const detail = await tokenResp.text().catch(() => '');
    console.error('[auth] discord token exchange failed:', tokenResp.status, detail);
    return res.status(401).json({ message: 'Could not verify Discord login. Please try again.' });
  }
  const tokenData = await tokenResp.json();

  // 2. Fetch the Discord identity behind that token.
  const meResp = await fetch('https://discord.com/api/users/@me', {
    headers: { Authorization: `${tokenData.token_type} ${tokenData.access_token}` },
  });
  if (!meResp.ok) return res.status(401).json({ message: 'Could not read Discord profile.' });
  const me = await meResp.json();

  const avatarUrl = me.avatar
    ? `https://cdn.discordapp.com/avatars/${me.id}/${me.avatar}.png`
    : `https://cdn.discordapp.com/embed/avatars/${Number(BigInt(me.id) % 6n)}.png`;

  // 3. Upsert their profile row. Only identity fields get overwritten on every
  //    login - display_name, tier, roles etc. are left alone once set.
  const { data: existing } = await supabaseAdmin
    .from('social_profiles')
    .select('*')
    .eq('discord_id', me.id)
    .maybeSingle();

  let profile = existing;
  if (!existing) {
    const { data: created, error: insertErr } = await supabaseAdmin
      .from('social_profiles')
      .insert({
        discord_id:   me.id,
        username:     me.username,
        display_name: me.global_name || me.username,
        avatar_url:   avatarUrl,
      })
      .select('*')
      .single();
    if (insertErr) {
      console.error('[auth] profile insert failed:', insertErr);
      return res.status(500).json({ message: 'Could not create your profile.' });
    }
    profile = created;
  } else {
    const { data: updated, error: updateErr } = await supabaseAdmin
      .from('social_profiles')
      .update({ username: me.username, avatar_url: avatarUrl, updated_at: new Date().toISOString() })
      .eq('discord_id', me.id)
      .select('*')
      .single();
    if (!updateErr) profile = updated;
  }

  const appToken = signAppToken(profile);
  const supabaseToken = signSupabaseToken(profile.discord_id);

  return res.status(200).json({
    token: appToken,
    supabaseToken,
    user: {
      id: profile.discord_id,
      username: profile.username,
      global_name: profile.display_name,
      avatar: profile.avatar_url,
      app_role: profile.app_role,
      tier: profile.tier,
      tier_expires_at: profile.tier_expires_at,
      is_tester: profile.is_tester,
      is_master_tester: profile.is_master_tester,
      is_contributor: profile.is_contributor,
    },
    discord_friends: [], // Discord hasn't granted relationships.read to this app
  });
}

async function handleRenew(req, res) {
  const claims = verifyAppToken(req.headers.authorization);
  if (!claims) return res.status(401).json({ message: 'Session expired, please sign in again.' });

  const { data: profile, error } = await supabaseAdmin
    .from('social_profiles')
    .select('*')
    .eq('discord_id', claims.id)
    .maybeSingle();

  if (error || !profile) return res.status(401).json({ message: 'Account no longer exists.' });

  return res.status(200).json({
    token: signAppToken(profile),
    supabaseToken: signSupabaseToken(profile.discord_id),
    tier_changed: profile.tier !== claims.tier,
    user: {
      id: profile.discord_id,
      username: profile.username,
      global_name: profile.display_name,
      avatar: profile.avatar_url,
      app_role: profile.app_role,
      tier: profile.tier,
      tier_expires_at: profile.tier_expires_at,
      is_tester: profile.is_tester,
      is_master_tester: profile.is_master_tester,
      is_contributor: profile.is_contributor,
    },
  });
}
