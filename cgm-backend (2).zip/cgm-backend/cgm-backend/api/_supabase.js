const { createClient } = require('@supabase/supabase-js');

// Service-role key: full access, bypasses RLS. This must NEVER be exposed to
// the client app - it only ever lives here, in this backend's environment.
const supabaseAdmin = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY,
  { auth: { autoRefreshToken: false, persistSession: false } }
);

module.exports = { supabaseAdmin };
