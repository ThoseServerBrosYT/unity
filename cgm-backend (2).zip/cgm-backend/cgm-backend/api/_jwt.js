// Shared helpers for minting and verifying the two tokens CGM uses:
//
//   - `token`         RS256, verified locally by the Electron app (auth.cjs)
//                      and by the injected game-mod's AuthModule.cs. Contains
//                      every claim the UI/mod gate on.
//   - `supabaseToken`  HS256, signed with the SAME secret you set as this
//                      Supabase project's "Legacy JWT Secret". This is what
//                      lets `auth.jwt()->>'discord_id'` work in RLS policies
//                      when the app queries Supabase directly.
//
// Both are 7 days, matching the client's expectations (see auth.cjs comments
// about "share a 7-day life").

const jwt = require('jsonwebtoken');

const JWT_PRIVATE_KEY       = process.env.JWT_PRIVATE_KEY;         // RS256 private key (PEM)
const SUPABASE_JWT_SECRET   = process.env.SUPABASE_JWT_SECRET;     // HS256 shared secret
const TOKEN_TTL_SECONDS     = 7 * 24 * 60 * 60;

function signAppToken(profile) {
  return jwt.sign(
    {
      iss:              'cgm',
      id:                profile.discord_id,
      username:          profile.username,
      global_name:       profile.display_name || profile.username,
      avatar:            profile.avatar_url,
      app_role:          profile.app_role || 'user',
      tier:              profile.tier || undefined,
      tier_expires_at:   profile.tier_expires_at || undefined,
      is_tester:         !!profile.is_tester,
      is_master_tester:  !!profile.is_master_tester,
      is_contributor:    !!profile.is_contributor,
    },
    JWT_PRIVATE_KEY,
    { algorithm: 'RS256', expiresIn: TOKEN_TTL_SECONDS }
  );
}

function signSupabaseToken(discordId) {
  return jwt.sign(
    {
      sub:         discordId,
      role:        'authenticated',
      discord_id:  discordId,
    },
    SUPABASE_JWT_SECRET,
    { algorithm: 'HS256', expiresIn: TOKEN_TTL_SECONDS }
  );
}

// Verifies the RS256 `token` sent as `Authorization: Bearer <token>` on every
// authenticated request. Returns the decoded payload, or null if invalid/expired.
function verifyAppToken(authHeader) {
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
  const token = authHeader.slice('Bearer '.length);
  try {
    const payload = jwt.verify(token, process.env.JWT_PUBLIC_KEY, { algorithms: ['RS256'] });
    if (payload.iss !== 'cgm') return null;
    return payload;
  } catch {
    return null;
  }
}

module.exports = { signAppToken, signSupabaseToken, verifyAppToken, TOKEN_TTL_SECONDS };
