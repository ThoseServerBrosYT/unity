# CGM backend

Handles Discord login, profile, and friends for your rebranded app. Marketplace,
moderation, and community-post features are intentionally not included (out of
scope per what you asked for).

## 1. Database

Open your Supabase project → SQL Editor → New query → paste all of `schema.sql`
→ Run.

Then, separately (can't be done via SQL): go to **Project Settings → API** (or
**JWT Keys**, depending on your Supabase dashboard version) and set the
**Legacy JWT Secret** to the exact value of `SUPABASE_JWT_SECRET` in
`ENV_VARS.txt`. This is what makes the app's direct database reads (friends
list, profile lookups) actually authenticate correctly - without this step,
every one of those reads will fail.

## 2. Discord app

In the Discord Developer Portal, on your application → OAuth2 → Redirects,
add exactly:
```
http://localhost:52139/callback
```

## 3. Deploy the backend

1. Push this folder to a new GitHub repo.
2. Import that repo in Vercel (vercel.com → Add New → Project).
3. Before the first deploy, open **Environment Variables** and add every line
   from `ENV_VARS.txt` (one variable per line, `NAME=value`).
4. Deploy. Vercel will give you a URL like `https://your-project.vercel.app`.

## 4. Point the app at your backend

Only one thing left: `electron/auth.cjs` in the app currently has:
```js
const AUTH_API_URL = process.env.AUTH_API_URL || 'https://REPLACE-WITH-YOUR-VERCEL-URL.vercel.app/api/auth';
```
Send me your real Vercel URL and I'll swap that in and repackage the app -
or edit it yourself and re-run `asar pack` if you'd rather do that part
locally.

## What's deliberately NOT here

- Mod uploading/hosting, download counts, storage quotas
- Community posts / anonymous community handles
- Moderation, ban appeals, reputation, creator badges

The app's UI for these will still show up in places (buttons, pages) but
their button actions will fail quietly, since nothing hooks up to a backend
for them. If you end up wanting any of these later, they can be added the
same way these were.

## Security notes

- `SUPABASE_SERVICE_KEY` and `DISCORD_CLIENT_SECRET` only ever live in
  Vercel's environment variables. They are never in the app's code.
- Rotate the Discord client secret and Supabase secret key once, since both
  were pasted in plain text earlier in our conversation - regenerating them
  costs nothing and closes that off. Just remember to update `ENV_VARS.txt`
  (and Vercel) with the new values afterward.
