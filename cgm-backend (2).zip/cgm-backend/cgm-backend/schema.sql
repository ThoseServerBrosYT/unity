-- CGM (Cabber's Gorilla Tag Modding) — social/profile/friends schema.
-- Run this once in Supabase: Dashboard -> SQL Editor -> New query -> paste -> Run.
--
-- Identity model: there is no Supabase Auth user table involved. Every row is
-- keyed directly by the Discord snowflake ID (`discord_id`). Row access is
-- controlled by RLS policies that check the `discord_id` custom claim baked
-- into the HS256 "supabaseToken" our backend issues (see api/_jwt.js).

-- ── social_profiles ─────────────────────────────────────────────────────
create table if not exists social_profiles (
  discord_id            text primary key,
  username              text not null,
  display_name          text,
  avatar_url            text,
  app_role              text not null default 'user',
  tier                  text,                -- null = free tier
  tier_expires_at       timestamptz,
  is_tester             boolean not null default false,
  is_master_tester      boolean not null default false,
  is_contributor        boolean not null default false,
  who_can_add           text not null default 'everyone',
  who_can_invite        text not null default 'everyone',
  appear_in_suggestions boolean not null default true,
  share_last_seen       boolean not null default true,
  profile_visibility    text not null default 'public',
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now()
);

alter table social_profiles enable row level security;

-- Anyone signed in can read any profile's public-facing fields (needed so you
-- can see your friends' names/avatars). Writing is restricted to your own row.
create policy "profiles are readable by any authenticated user"
  on social_profiles for select
  to authenticated
  using (true);

create policy "users can update their own profile"
  on social_profiles for update
  to authenticated
  using (discord_id = auth.jwt()->>'discord_id')
  with check (discord_id = auth.jwt()->>'discord_id');

create policy "users can insert their own profile"
  on social_profiles for insert
  to authenticated
  with check (discord_id = auth.jwt()->>'discord_id');

-- ── friendships ──────────────────────────────────────────────────────────
-- One row per relationship. status: 'pending' | 'accepted' | 'blocked'.
-- initiated_by records who sent the request / issued the block, so the app
-- can tell incoming vs outgoing requests apart.
create table if not exists friendships (
  user_a         text not null references social_profiles(discord_id) on delete cascade,
  user_b         text not null references social_profiles(discord_id) on delete cascade,
  status         text not null default 'pending' check (status in ('pending','accepted','blocked')),
  initiated_by   text not null,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  primary key (user_a, user_b),
  check (user_a < user_b)  -- canonical ordering so (A,B) and (B,A) never both exist
);

alter table friendships enable row level security;

create policy "users can read their own friendships"
  on friendships for select
  to authenticated
  using (auth.jwt()->>'discord_id' in (user_a, user_b));

-- All writes go through the backend (service role), which enforces the
-- actual request/accept/block rules server-side, so there is no direct
-- insert/update/delete policy for regular users here on purpose.

-- ── pinned_friends ───────────────────────────────────────────────────────
create table if not exists pinned_friends (
  discord_id  text not null references social_profiles(discord_id) on delete cascade,
  pinned_id   text not null,
  position    int not null default 0,
  primary key (discord_id, pinned_id)
);

alter table pinned_friends enable row level security;

create policy "users manage their own pins"
  on pinned_friends for all
  to authenticated
  using (discord_id = auth.jwt()->>'discord_id')
  with check (discord_id = auth.jwt()->>'discord_id');

-- ── notification_prefs ───────────────────────────────────────────────────
create table if not exists notification_prefs (
  discord_id  text primary key references social_profiles(discord_id) on delete cascade,
  prefs       jsonb not null default '{}'::jsonb
);

alter table notification_prefs enable row level security;

create policy "users manage their own notification prefs"
  on notification_prefs for all
  to authenticated
  using (discord_id = auth.jwt()->>'discord_id')
  with check (discord_id = auth.jwt()->>'discord_id');

-- ── notifications ────────────────────────────────────────────────────────
create table if not exists notifications (
  id            uuid primary key default gen_random_uuid(),
  recipient_id  text not null references social_profiles(discord_id) on delete cascade,
  kind          text not null,
  payload       jsonb not null default '{}'::jsonb,
  read_at       timestamptz,
  created_at    timestamptz not null default now()
);

alter table notifications enable row level security;

create policy "users read their own notifications"
  on notifications for select
  to authenticated
  using (recipient_id = auth.jwt()->>'discord_id');

create policy "users can mark their own notifications read"
  on notifications for update
  to authenticated
  using (recipient_id = auth.jwt()->>'discord_id')
  with check (recipient_id = auth.jwt()->>'discord_id');

-- ── presence ─────────────────────────────────────────────────────────────
create table if not exists presence (
  discord_id  text primary key references social_profiles(discord_id) on delete cascade,
  status      text not null default 'offline',
  updated_at  timestamptz not null default now()
);

alter table presence enable row level security;

create policy "presence is readable by any authenticated user"
  on presence for select
  to authenticated
  using (true);

create policy "users update their own presence"
  on presence for all
  to authenticated
  using (discord_id = auth.jwt()->>'discord_id')
  with check (discord_id = auth.jwt()->>'discord_id');

-- ── Configure Supabase to trust our own HS256 tokens ────────────────────
-- IMPORTANT MANUAL STEP (cannot be done via SQL):
-- Dashboard -> Project Settings -> JWT Keys / API -> "Legacy JWT Secret"
-- must be set to the exact value in keys/supabase_jwt_secret.txt from this
-- delivery. That is what makes `auth.jwt()->>'discord_id'` above resolve
-- correctly for tokens minted by our own backend (api/_jwt.js), instead of
-- Supabase's own (unused) auth system.
